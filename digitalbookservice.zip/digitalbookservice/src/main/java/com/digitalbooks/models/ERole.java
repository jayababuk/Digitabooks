package com.digitalbooks.models;

public enum ERole {
	ROLE_AUTHOR,
	ROLE_READER
}
