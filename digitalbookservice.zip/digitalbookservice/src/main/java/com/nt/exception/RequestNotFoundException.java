package com.nt.exception;

public class RequestNotFoundException extends Exception {
	public RequestNotFoundException(String message) {
		super(message);
	}
	public RequestNotFoundException() {
		
	}

}
